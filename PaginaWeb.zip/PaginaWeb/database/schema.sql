DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS ventas;
DROP TABLE IF EXISTS users;

CREATE TABLE productos (
    id INTEGER PRIMARY KEY,
    nombre TEXT,
    tipo TEXT,
    plataforma TEXT,
    precio REAL,
    descripcion TEXT,
    imagen TEXT
);

INSERT INTO productos VALUES
(1, 'Ubuntu 22.04', 'Sistema Operativo', 'Linux', 15.00, 'Distribución estable.', 'ubuntu.png'),
(2, 'Debian 12', 'Sistema Operativo', 'Linux', 13.00, 'Sistema robusto.', 'debian.png'),
(3, 'Kali Linux', 'Pentesting', 'Linux', 8.00, 'Sistema para seguridad.', 'kali.png'), 
(4, 'Linux Mint 21', 'Escritorio', 'Linux', 25.00, 'Ideal para principiantes.', 'mint.png'),
(5, 'Zorin OS 17 Pro', 'Escritorio', 'Linux', 39.00, 'Interfaz premium similar a Windows 11.', 'zorin.png'),
(6, 'Red Hat Enterprise', 'Servidor', 'Linux', 349.99, 'Estándar corporativo con soporte.', 'redhat.png'),
(7, 'macOS Sonoma', 'Sistema Operativo', 'Mac', 19.99, 'Sistema exclusivo para hardware Apple.', 'macos.png'),
(8, 'SteamOS 3', 'Gaming', 'Linux', 34.00, 'Optimizado para videojuegos y Steam.', 'steamos.png'),
(9, 'Elementary OS', 'Diseño', 'Linux', 15.00, 'La distro más elegante, estilo Mac.', 'elementary.png'),
(10, 'FreeBSD 14', 'Servidor', 'BSD', 12.00, 'Sistema UNIX avanzado y robusto.', 'freebsd.png'),
(11, 'Tails OS', 'Privacidad', 'Linux', 19.00, 'Navegación anónima y segura.', 'tails.png'),
(12, 'Manjaro Linux', 'Desarrollo', 'Linux', 12.00, 'Basado en Arch, siempre actualizado.', 'manjaro.png'),
(13, 'Android x86', 'Móvil/PC', 'Android', 7.00, 'Android adaptado para computadoras.', 'android.png');
COMMIT;

CREATE TABLE ventas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT,
    correo TEXT,
    metodo TEXT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    nombre TEXT NOT NULL,
    correo TEXT NOT NULL,
    telefono TEXT,
    direccion TEXT
);

