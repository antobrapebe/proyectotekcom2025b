// ===== Modales =====
function mostrarModal(id) {
    document.getElementById(id).classList.add("activo");
}

function cerrarModal(id) {
    document.getElementById(id).classList.remove("activo");
}

// ===== Carrito =====
function agregarCarrito(id) {
    fetch("/agregar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
    }).then(() => {
        alert("Producto agregado al carrito");
        cargarCarrito();
    });
}

function cargarCarrito() {
    fetch("/carrito")
        .then(r => r.json())
        .then(data => {
            const container = document.getElementById("carritoItems");
            container.innerHTML = "";
            if(data.length === 0){
                container.innerHTML = "<p>Carrito vacío</p>";
            } else {
                data.forEach(p => {
                    container.innerHTML += `<p>${p.nombre} — $${p.precio}</p>`;
                });
            }
        });
}

function comprar() {
    const nombre = document.getElementById("nombre").value;
    const correo = document.getElementById("correo").value;
    const metodo = document.getElementById("metodo").value;

    fetch("/comprar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nombre, correo, metodo })
    }).then(r => r.json())
      .then(resp => {
          if(resp.status === "compra_exitosa"){
              alert("Compra realizada con éxito");
              cerrarModal('modalCarrito');
          }
      });
}

// ===== Login =====
function login(event){
    event.preventDefault();
    const usuario = document.getElementById("loginUsuario").value;
    const password = document.getElementById("loginPassword").value;

    fetch("/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ usuario, password })
    }).then(r => r.json())
      .then(resp => {
          if(resp.status === "ok"){
              alert("Sesión iniciada");
              cerrarModal('modalLogin');
              location.reload();
          } else {
              alert("Usuario o contraseña incorrectos");
          }
      });
}

// ===== Registro =====
function register(event){
    event.preventDefault();
    const usuario = document.getElementById("registerUsuario").value;
    const password = document.getElementById("registerPassword").value;
    const nombre = document.getElementById("registerNombre").value;
    const correo = document.getElementById("registerCorreo").value;
    const telefono = document.getElementById("registerTelefono").value;
    const direccion = document.getElementById("registerDireccion").value;

    fetch("/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ usuario, password, nombre, correo, telefono, direccion })
    }).then(r => r.json())
      .then(resp => {
          if(resp.status === "ok"){
              alert("Registro exitoso");
              cerrarModal('modalRegister');
          } else {
              alert(resp.msg);
          }
      });
}

// ===== Búsqueda =====
function filtrarProductos() {
    const filtro = document.getElementById("busqueda").value.toLowerCase();
    const cards = document.querySelectorAll(".grid .card");
    cards.forEach(card => {
        const nombre = card.querySelector("h3").textContent.toLowerCase();
        const tipo = card.querySelector("p").textContent.toLowerCase();
        card.style.display = (nombre.includes(filtro) || tipo.includes(filtro)) ? "block" : "none";
    });
}